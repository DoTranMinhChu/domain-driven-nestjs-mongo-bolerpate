import { UserLoginInputType } from '@presentation/graphql/input-types/user';

export class UserLoginInputDTO extends UserLoginInputType {}
