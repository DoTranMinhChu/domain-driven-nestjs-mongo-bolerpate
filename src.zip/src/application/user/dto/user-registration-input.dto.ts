import { UserRegistrationInputType } from '@presentation/graphql/input-types/user';

export class UserRegistrationInputDTO extends UserRegistrationInputType {}
