export * from './query-get-list-graphql.decorator';
