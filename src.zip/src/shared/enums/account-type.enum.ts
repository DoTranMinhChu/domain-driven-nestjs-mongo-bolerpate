export enum EAccountType {
    USER = "USER",
    ADMIN = "ADMIN",
}