export * from './mongoose-base.interface';
