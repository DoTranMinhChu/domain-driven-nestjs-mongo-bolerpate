export * from './create-post.input-schema';
export * from './update-post.input-schema';