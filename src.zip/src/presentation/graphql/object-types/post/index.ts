export * from './post.object-type';
