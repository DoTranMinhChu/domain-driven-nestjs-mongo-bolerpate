export * from './query-get-list.input-type';
