export * from './post.repository.abstract';
